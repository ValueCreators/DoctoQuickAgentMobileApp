Ext.define('DoctorRegister.view.registration.CapturePic', {
    extend: 'Ext.Panel',
    xtype: 'capturePicScreen',
    config: {}
});
