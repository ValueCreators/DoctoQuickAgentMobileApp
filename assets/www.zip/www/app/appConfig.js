var config = {
	'serviceURL' : 'http://52.25.74.102/'
}